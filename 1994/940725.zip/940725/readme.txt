bad session
